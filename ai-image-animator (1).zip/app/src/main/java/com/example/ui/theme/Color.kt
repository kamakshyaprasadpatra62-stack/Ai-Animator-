package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette
val MinimalBg = Color(0xFFFEF7FF)
val MinimalSurface = Color(0xFFECE6F0)
val MinimalSurfaceElevated = Color(0xFFF3EDF7)
val MinimalBorder = Color(0xFFCAC4D0)

val MinimalPrimary = Color(0xFF6750A4)
val MinimalOnPrimary = Color(0xFFFFFFFF)
val MinimalPrimaryContainer = Color(0xFFEADDFF)
val MinimalOnPrimaryContainer = Color(0xFF21005D)

val MinimalSecondaryContainer = Color(0xFFE8DEF8)
val MinimalOnSecondaryContainer = Color(0xFF1D192B)
val MinimalSecondary = Color(0xFF625B71)

val MinimalTextPrimary = Color(0xFF1D1B20)
val MinimalTextSecondary = Color(0xFF49454F)
val MinimalTextMuted = Color(0xFF79747E)

// Backward compatibility mappings
val StudioDarkBg = MinimalBg
val StudioCardBg = MinimalSurface
val StudioCardElevated = MinimalSurfaceElevated
val StudioBorder = MinimalBorder

val StudioVioletPrimary = MinimalPrimary
val StudioCyanAccent = MinimalPrimary
val StudioNeonPink = Color(0xFFB3261E)
val StudioGlowGold = Color(0xFF7D5260)

val TextPrimary = MinimalTextPrimary
val TextSecondary = MinimalTextSecondary
val TextMuted = MinimalTextMuted

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = MinimalPrimary
val PurpleGrey40 = MinimalSecondary
val Pink40 = Color(0xFF7D5260)

