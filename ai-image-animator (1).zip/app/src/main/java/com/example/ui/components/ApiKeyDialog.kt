package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalOnPrimaryContainer
import com.example.ui.theme.MinimalPrimary
import com.example.ui.theme.MinimalPrimaryContainer
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceElevated
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary

@Composable
fun ApiKeyDialog(
    currentKey: String,
    currentEngineMode: String,
    onSaveKey: (String) -> Unit,
    onEngineModeSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var keyText by remember { mutableStateOf(currentKey) }
    var isPasswordVisible by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = MinimalSurfaceElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = MinimalPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.dialog_settings_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalTextPrimary
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.dialog_settings_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MinimalTextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Engine Priority",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = currentEngineMode == "auto",
                        onClick = { onEngineModeSelected("auto") },
                        label = { Text("Auto (Cloud / Local)", fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                        shape = RoundedCornerShape(50),
                        leadingIcon = if (currentEngineMode == "auto") {
                            { Icon(Icons.Default.Check, null) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.Transparent,
                            labelColor = MinimalTextSecondary,
                            selectedContainerColor = MinimalPrimaryContainer,
                            selectedLabelColor = MinimalOnPrimaryContainer,
                            selectedLeadingIconColor = MinimalOnPrimaryContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = currentEngineMode == "auto",
                            borderColor = MinimalBorder,
                            selectedBorderColor = Color.Transparent
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = currentEngineMode == "local",
                        onClick = { onEngineModeSelected("local") },
                        label = { Text("Device Only", fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                        shape = RoundedCornerShape(50),
                        leadingIcon = if (currentEngineMode == "local") {
                            { Icon(Icons.Default.Check, null) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.Transparent,
                            labelColor = MinimalTextSecondary,
                            selectedContainerColor = MinimalPrimaryContainer,
                            selectedLabelColor = MinimalOnPrimaryContainer,
                            selectedLeadingIconColor = MinimalOnPrimaryContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = currentEngineMode == "local",
                            borderColor = MinimalBorder,
                            selectedBorderColor = Color.Transparent
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Gemini API Key",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    placeholder = { Text("AIzaSy...", color = MinimalTextMuted) },
                    visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (isPasswordVisible) "Hide Key" else "Show Key",
                                tint = MinimalTextSecondary
                            )
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MinimalPrimary,
                        unfocusedBorderColor = MinimalBorder,
                        focusedTextColor = MinimalTextPrimary,
                        unfocusedTextColor = MinimalTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Configuring GEMINI_API_KEY in AI Studio Secrets will automatically link to Veo 3.1 video generation.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextMuted
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSaveKey(keyText) },
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPrimary),
                shape = RoundedCornerShape(50),
                modifier = Modifier.testTag("save_key_button")
            ) {
                Text(stringResource(R.string.btn_save_key), color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(50),
                border = androidx.compose.foundation.BorderStroke(1.dp, MinimalBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalTextSecondary)
            ) {
                Text(stringResource(R.string.btn_close))
            }
        }
    )
}
