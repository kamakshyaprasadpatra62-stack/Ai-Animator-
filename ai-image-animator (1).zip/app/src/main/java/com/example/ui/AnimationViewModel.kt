package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.R
import com.example.data.api.VeoAnimationService
import com.example.data.engine.LocalMotionVideoSynthesizer
import com.example.data.local.AppDatabase
import com.example.data.model.AnimationItem
import com.example.data.repository.AnimationRepository
import com.example.util.FileUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class AnimationUiState(
    val selectedImageUri: Uri? = null,
    val selectedSampleResId: Int? = R.drawable.sample_cyberpunk,
    val prompt: String = "Cinematic slow forward zoom, rain splashing with glowing neon reflections, car headlights shimmering in wet asphalt",
    val aspectRatio: String = "16:9",
    val motionStyle: String = "Cinematic Drone Push",
    val engineMode: String = "auto", // "auto", "veo", "local"
    val isGenerating: Boolean = false,
    val progress: Float = 0f,
    val statusMessage: String = "",
    val activeVideoItem: AnimationItem? = null,
    val selectedTab: Int = 0, // 0 = Create, 1 = Player, 2 = History
    val errorMessage: String? = null,
    val showSettingsDialog: Boolean = false,
    val apiKey: String = ""
)

class AnimationViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AnimationRepository
    private val veoService = VeoAnimationService(application)
    private val localEngine = LocalMotionVideoSynthesizer(application)

    private val _uiState = MutableStateFlow(AnimationUiState())
    val uiState: StateFlow<AnimationUiState> = _uiState.asStateFlow()

    val savedAnimations: StateFlow<List<AnimationItem>>

    private var currentJob: Job? = null

    companion object {
        private const val PREFS_NAME = "image_animator_prefs"
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
    }

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AnimationRepository(database.animationDao())
        savedAnimations = repository.allAnimations.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Load saved API key or fallback to BuildConfig
        val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedKey = prefs.getString(KEY_CUSTOM_API_KEY, null)
        val defaultKey = if (!savedKey.isNullOrBlank()) {
            savedKey
        } else {
            try {
                BuildConfig.GEMINI_API_KEY
            } catch (e: Exception) {
                ""
            }
        }
        _uiState.value = _uiState.value.copy(apiKey = defaultKey)
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.value = _uiState.value.copy(prompt = newPrompt, errorMessage = null)
    }

    fun onAspectRatioChange(ratio: String) {
        _uiState.value = _uiState.value.copy(aspectRatio = ratio)
    }

    fun onMotionStyleChange(style: String, samplePrompt: String? = null) {
        _uiState.value = _uiState.value.copy(
            motionStyle = style,
            prompt = samplePrompt ?: _uiState.value.prompt
        )
    }

    fun onImageSelected(uri: Uri) {
        _uiState.value = _uiState.value.copy(
            selectedImageUri = uri,
            selectedSampleResId = null,
            errorMessage = null
        )
    }

    fun onSampleSelected(resId: Int, presetPrompt: String) {
        _uiState.value = _uiState.value.copy(
            selectedImageUri = null,
            selectedSampleResId = resId,
            prompt = presetPrompt,
            errorMessage = null
        )
    }

    fun onTabSelected(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(selectedTab = tabIndex)
    }

    fun toggleSettingsDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showSettingsDialog = show)
    }

    fun saveApiKey(newKey: String) {
        val trimmed = newKey.trim()
        val prefs = getApplication<Application>().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_CUSTOM_API_KEY, trimmed).apply()
        _uiState.value = _uiState.value.copy(apiKey = trimmed, showSettingsDialog = false)
    }

    fun setEngineMode(mode: String) {
        _uiState.value = _uiState.value.copy(engineMode = mode)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun setActiveVideo(item: AnimationItem) {
        _uiState.value = _uiState.value.copy(
            activeVideoItem = item,
            selectedTab = 1
        )
    }

    fun generateAnimation() {
        val state = _uiState.value
        val context = getApplication<Application>()

        val bitmap: Bitmap? = FileUtils.loadBitmap(
            context,
            state.selectedImageUri,
            state.selectedSampleResId
        )

        if (bitmap == null) {
            _uiState.value = state.copy(errorMessage = "Please select or choose an image first.")
            return
        }

        if (state.prompt.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Please enter an animation motion prompt.")
            return
        }

        currentJob?.cancel()
        currentJob = viewModelScope.launch {
            _uiState.value = state.copy(
                isGenerating = true,
                progress = 0.05f,
                statusMessage = "Analyzing static image...",
                errorMessage = null
            )

            try {
                // Save static image permanently for history & comparison
                val savedImageFile = FileUtils.saveBitmapToFile(context, bitmap, "source")

                val useVeo = (state.engineMode == "veo") ||
                        (state.engineMode == "auto" && state.apiKey.isNotBlank())

                var generatedVideoFile: File
                var modelName: String

                if (useVeo) {
                    try {
                        _uiState.value = _uiState.value.copy(
                            statusMessage = "Connecting to Google Veo AI Model...",
                            progress = 0.15f
                        )
                        modelName = "Google Veo 3.1"
                        generatedVideoFile = veoService.generateVideoWithVeo(
                            apiKey = state.apiKey,
                            bitmap = bitmap,
                            prompt = state.prompt,
                            aspectRatio = state.aspectRatio,
                            model = VeoAnimationService.MODEL_VEO_FAST
                        ) { msg, prog ->
                            _uiState.value = _uiState.value.copy(
                                statusMessage = msg,
                                progress = prog
                            )
                        }
                    } catch (veoEx: Exception) {
                        Log.w("AnimationVM", "Veo generation failed, falling back to local engine: ${veoEx.message}")
                        if (state.engineMode == "veo") {
                            throw veoEx
                        }
                        // Fallback to high-quality local motion synthesizer
                        _uiState.value = _uiState.value.copy(
                            statusMessage = "Veo cloud busy, synthesizing via Neural Motion Engine...",
                            progress = 0.20f
                        )
                        generatedVideoFile = localEngine.synthesizeMotionVideo(
                            bitmap = bitmap,
                            prompt = state.prompt,
                            aspectRatio = state.aspectRatio,
                            durationSeconds = 4
                        ) { msg, prog ->
                            _uiState.value = _uiState.value.copy(
                                statusMessage = msg,
                                progress = prog
                            )
                        }
                    }
                } else {
                    modelName = "Neural Motion Engine"
                    generatedVideoFile = localEngine.synthesizeMotionVideo(
                        bitmap = bitmap,
                        prompt = state.prompt,
                        aspectRatio = state.aspectRatio,
                        durationSeconds = 4
                    ) { msg, prog ->
                        _uiState.value = _uiState.value.copy(
                            statusMessage = msg,
                            progress = prog
                        )
                    }
                }

                // Record into Room Database
                val item = AnimationItem(
                    prompt = state.prompt,
                    imagePath = savedImageFile.absolutePath,
                    videoPath = generatedVideoFile.absolutePath,
                    aspectRatio = state.aspectRatio,
                    motionStyle = state.motionStyle,
                    modelName = if (useVeo) "Google Veo 3.1" else "AI Motion Engine"
                )
                val newId = repository.insertAnimation(item)
                val fullItem = item.copy(id = newId)

                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    progress = 1.0f,
                    statusMessage = "Video Ready!",
                    activeVideoItem = fullItem,
                    selectedTab = 1 // Switch directly to result player!
                )

            } catch (e: Exception) {
                Log.e("AnimationVM", "Generation error", e)
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    errorMessage = e.message ?: "Failed to generate video clip"
                )
            }
        }
    }

    fun cancelGeneration() {
        currentJob?.cancel()
        _uiState.value = _uiState.value.copy(
            isGenerating = false,
            statusMessage = "Generation cancelled",
            progress = 0f
        )
    }

    fun deleteAnimation(item: AnimationItem) {
        viewModelScope.launch {
            repository.deleteAnimationById(item.id)
            try {
                File(item.videoPath).delete()
                File(item.imagePath).delete()
            } catch (e: Exception) {
                // ignore
            }
            if (_uiState.value.activeVideoItem?.id == item.id) {
                _uiState.value = _uiState.value.copy(activeVideoItem = null, selectedTab = 0)
            }
        }
    }
}
