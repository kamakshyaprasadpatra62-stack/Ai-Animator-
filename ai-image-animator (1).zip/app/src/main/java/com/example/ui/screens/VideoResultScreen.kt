package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.AnimationItem
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.MinimalBg
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalOnPrimaryContainer
import com.example.ui.theme.MinimalOnSecondaryContainer
import com.example.ui.theme.MinimalPrimary
import com.example.ui.theme.MinimalPrimaryContainer
import com.example.ui.theme.MinimalSecondaryContainer
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceElevated
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.util.FileUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideoResultScreen(
    animationItem: AnimationItem?,
    onGenerateNew: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var previewModeIndex by remember { mutableIntStateOf(0) } // 0 = Video Clip, 1 = Static Image

    if (animationItem == null) {
        Box(
            modifier = modifier.fillMaxSize().background(MinimalBg),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Movie,
                    contentDescription = null,
                    tint = MinimalTextMuted,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No animation generated yet",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pick a picture and describe your prompt to create an AI animated video clip.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MinimalTextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onGenerateNew,
                    colors = ButtonDefaults.buttonColors(containerColor = MinimalPrimary),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("create_first_animation_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create Animation", fontWeight = FontWeight.SemiBold, color = Color.White)
                }
            }
        }
        return
    }

    val ratioValue = if (animationItem.aspectRatio == "9:16") 9f / 16f else 16f / 9f

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AI Animation Clip",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalTextPrimary
                )
                Text(
                    text = "High definition motion clip generated from prompt",
                    style = MaterialTheme.typography.bodySmall,
                    color = MinimalTextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = MinimalSecondaryContainer,
                border = BorderStroke(1.dp, MinimalBorder)
            ) {
                Text(
                    text = animationItem.modelName,
                    color = MinimalOnSecondaryContainer,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Comparison Tab (Animated Video vs Static Original)
        TabRow(
            selectedTabIndex = previewModeIndex,
            containerColor = MinimalSurfaceElevated,
            contentColor = MinimalPrimary,
            indicator = { tabPositions ->
                SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[previewModeIndex]),
                    color = MinimalPrimary
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(BorderStroke(1.dp, MinimalBorder), RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = previewModeIndex == 0,
                onClick = { previewModeIndex = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Movie,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (previewModeIndex == 0) MinimalPrimary else MinimalTextSecondary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Animated Video Clip",
                            fontWeight = FontWeight.SemiBold,
                            color = if (previewModeIndex == 0) MinimalPrimary else MinimalTextSecondary
                        )
                    }
                },
                modifier = Modifier.testTag("tab_video_clip")
            )
            Tab(
                selected = previewModeIndex == 1,
                onClick = { previewModeIndex = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Photo,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (previewModeIndex == 1) MinimalPrimary else MinimalTextSecondary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Static Original",
                            fontWeight = FontWeight.SemiBold,
                            color = if (previewModeIndex == 1) MinimalPrimary else MinimalTextSecondary
                        )
                    }
                },
                modifier = Modifier.testTag("tab_static_original")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Display area: Video or Static Image
        Crossfade(targetState = previewModeIndex, label = "PreviewCrossfade") { mode ->
            if (mode == 0) {
                VideoPlayerView(
                    videoPath = animationItem.videoPath,
                    aspectRatioStr = animationItem.aspectRatio,
                    modifier = Modifier.testTag("video_player_view")
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(ratioValue)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(File(animationItem.imagePath))
                            .crossfade(true)
                            .build(),
                        contentDescription = "Original static image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MinimalPrimaryContainer,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "ORIGINAL STILL PHOTO",
                            color = MinimalOnPrimaryContainer,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Action Buttons Row (Share, Save to Gallery)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { FileUtils.shareVideo(context, animationItem.videoPath) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalSurfaceElevated,
                    contentColor = MinimalPrimary
                ),
                border = BorderStroke(1.dp, MinimalBorder),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("share_video_button")
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = MinimalPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.btn_share_video), color = MinimalTextPrimary, fontWeight = FontWeight.Medium)
            }

            Button(
                onClick = { FileUtils.saveVideoToGallery(context, animationItem.videoPath) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalSurfaceElevated,
                    contentColor = MinimalPrimary
                ),
                border = BorderStroke(1.dp, MinimalBorder),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("save_video_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, tint = MinimalPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.btn_export_video), color = MinimalTextPrimary, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = onGenerateNew,
            colors = ButtonDefaults.buttonColors(containerColor = MinimalPrimary),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("new_video_button")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Generate Another Animation", fontWeight = FontWeight.SemiBold, color = Color.White)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Details Card
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MinimalSurface),
            border = BorderStroke(1.dp, MinimalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Prompt Details",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MinimalPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "\"${animationItem.prompt}\"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MinimalTextPrimary
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Style Preset", style = MaterialTheme.typography.labelSmall, color = MinimalTextMuted)
                        Text(animationItem.motionStyle, style = MaterialTheme.typography.bodySmall, color = MinimalTextSecondary)
                    }
                    Column {
                        Text("Aspect Ratio", style = MaterialTheme.typography.labelSmall, color = MinimalTextMuted)
                        Text(animationItem.aspectRatio, style = MaterialTheme.typography.bodySmall, color = MinimalTextSecondary)
                    }
                    Column {
                        Text("Created", style = MaterialTheme.typography.labelSmall, color = MinimalTextMuted)
                        val formattedDate = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
                            .format(Date(animationItem.timestamp))
                        Text(formattedDate, style = MaterialTheme.typography.bodySmall, color = MinimalTextSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
