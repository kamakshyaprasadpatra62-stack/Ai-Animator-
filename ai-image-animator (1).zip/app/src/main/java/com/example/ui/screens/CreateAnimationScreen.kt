package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop169
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.AnimationUiState
import com.example.ui.theme.MinimalBg
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalOnPrimaryContainer
import com.example.ui.theme.MinimalPrimary
import com.example.ui.theme.MinimalPrimaryContainer
import com.example.ui.theme.MinimalSecondaryContainer
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceElevated
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary

@Composable
fun CreateAnimationScreen(
    uiState: AnimationUiState,
    onImagePicked: (Uri) -> Unit,
    onSampleSelected: (Int, String) -> Unit,
    onPromptChanged: (String) -> Unit,
    onAspectRatioChanged: (String) -> Unit,
    onMotionStyleSelected: (String, String) -> Unit,
    onGenerateClicked: () -> Unit,
    onCancelGeneration: () -> Unit,
    onOpenSettings: () -> Unit,
    onClearError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    // Android Photo Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onImagePicked(uri)
        }
    }

    val motionPresets = listOf(
        Pair("Cinematic Rain Zoom", "Slow forward camera push, pouring rain splashing on ground with glowing neon reflections and mist"),
        Pair("Cascading Water & Glow", "Water cascading down dynamically with misty foam spray, gentle wave ripples and glowing bioluminescent flora"),
        Pair("Cyberpunk Neon Pulse", "Holographic billboards flickering, neon light streaks gliding across reflective metallic car bodies"),
        Pair("Drone Fly-Through", "Dynamic high-speed aerial drone glide into the scenery with atmospheric depth and natural lighting shifts"),
        Pair("Ethereal Breeze & Sparks", "Gentle wind swaying foliage, floating glowing dust motes and soft cinematic sunbeams drifting")
    )

    Box(modifier = modifier.fillMaxSize().background(MinimalBg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Header matching Clean Minimalism
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(MinimalPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Motion AI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = (-0.5).sp,
                            color = MinimalTextPrimary
                        )
                        Text(
                            text = stringResource(R.string.subtitle_generator),
                            style = MaterialTheme.typography.bodySmall,
                            color = MinimalTextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Settings",
                        tint = MinimalTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Error Banner if any
            if (uiState.errorMessage != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9DEDC)),
                    border = BorderStroke(1.dp, Color(0xFFB3261E))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = uiState.errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF410E0B),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onClearError, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, "Dismiss", tint = Color(0xFF410E0B))
                        }
                    }
                }
            }

            // SECTION 1: Source Image Card (Clean Minimalism aspect 4/3, rounded 28dp, border #CAC4D0)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MinimalSurface),
                border = BorderStroke(1.dp, MinimalBorder)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(if (uiState.aspectRatio == "9:16") 9f / 16f else 4f / 3f),
                    contentAlignment = Alignment.Center
                ) {
                    if (uiState.selectedImageUri != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(uiState.selectedImageUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Selected static image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (uiState.selectedSampleResId != null) {
                        Image(
                            painter = painterResource(id = uiState.selectedSampleResId),
                            contentDescription = "Sample static image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = MinimalTextSecondary.copy(alpha = 0.4f),
                                modifier = Modifier.size(54.dp)
                            )
                            Text(
                                text = "Tap to upload source image",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MinimalTextSecondary
                            )
                            Text(
                                text = "PNG, JPG up to 10MB",
                                style = MaterialTheme.typography.bodySmall,
                                color = MinimalTextSecondary.copy(alpha = 0.6f)
                            )
                        }
                    }

                    // Badge on image indicating "Static Source"
                    if (uiState.selectedImageUri != null || uiState.selectedSampleResId != null) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MinimalPrimaryContainer,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "STATIC SOURCE",
                                color = MinimalOnPrimaryContainer,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action row: pick custom image or change
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("pick_image_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalSurfaceElevated,
                    contentColor = MinimalPrimary
                ),
                border = BorderStroke(1.dp, MinimalBorder)
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = null,
                    tint = MinimalPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (uiState.selectedImageUri != null || uiState.selectedSampleResId != null)
                        stringResource(R.string.btn_change_image)
                    else
                        stringResource(R.string.btn_pick_image),
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Try samples row
            Text(
                text = stringResource(R.string.label_try_samples),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                color = MinimalTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Sample 1: Cyberpunk
                val isCyberSelected = uiState.selectedSampleResId == R.drawable.sample_cyberpunk
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = if (isCyberSelected) 2.dp else 1.dp,
                            color = if (isCyberSelected) MinimalPrimary else MinimalBorder,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            onSampleSelected(
                                R.drawable.sample_cyberpunk,
                                "Cinematic slow forward zoom, rain splashing with glowing neon reflections, car headlights shimmering in wet asphalt"
                            )
                        }
                ) {
                    Image(
                        painter = painterResource(R.drawable.sample_cyberpunk),
                        contentDescription = "Cyberpunk Sample",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = Color(0x991D1B20),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "Neon City",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(2.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                // Sample 2: Waterfall
                val isWaterSelected = uiState.selectedSampleResId == R.drawable.sample_waterfall
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = if (isWaterSelected) 2.dp else 1.dp,
                            color = if (isWaterSelected) MinimalPrimary else MinimalBorder,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            onSampleSelected(
                                R.drawable.sample_waterfall,
                                "Water cascading down dynamically with misty foam spray, gentle wave ripples and glowing bioluminescent flora"
                            )
                        }
                ) {
                    Image(
                        painter = painterResource(R.drawable.sample_waterfall),
                        contentDescription = "Waterfall Sample",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = Color(0x991D1B20),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "Waterfall",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(2.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // SECTION 2: Animation Prompt
            Text(
                text = "ANIMATION PROMPT",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MinimalPrimary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = uiState.prompt,
                onValueChange = onPromptChanged,
                placeholder = {
                    Text(
                        stringResource(R.string.prompt_placeholder),
                        color = MinimalTextMuted,
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .testTag("prompt_input"),
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPrimary,
                    unfocusedBorderColor = MinimalBorder,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Preset motion style chips
            Text(
                text = stringResource(R.string.label_motion_styles),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                color = MinimalTextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                motionPresets.forEach { (name, promptText) ->
                    val isSelected = uiState.prompt == promptText
                    FilterChip(
                        selected = isSelected,
                        onClick = { onMotionStyleSelected(name, promptText) },
                        label = { Text(name, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                        shape = RoundedCornerShape(50),
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.Transparent,
                            labelColor = MinimalTextSecondary,
                            selectedContainerColor = MinimalPrimaryContainer,
                            selectedLabelColor = MinimalOnPrimaryContainer,
                            selectedLeadingIconColor = MinimalOnPrimaryContainer
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = MinimalBorder,
                            selectedBorderColor = Color.Transparent
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // SECTION 3: Aspect Ratio
            Text(
                text = stringResource(R.string.section_aspect_ratio),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                color = MinimalTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val is169 = uiState.aspectRatio == "16:9"
                FilterChip(
                    selected = is169,
                    onClick = { onAspectRatioChanged("16:9") },
                    label = { Text("16:9 Landscape", fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                    leadingIcon = { Icon(Icons.Default.Crop169, null, modifier = Modifier.size(16.dp)) },
                    shape = RoundedCornerShape(50),
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color.Transparent,
                        labelColor = MinimalTextSecondary,
                        selectedContainerColor = MinimalPrimaryContainer,
                        selectedLabelColor = MinimalOnPrimaryContainer,
                        selectedLeadingIconColor = MinimalOnPrimaryContainer
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = is169,
                        borderColor = MinimalBorder,
                        selectedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )

                val is916 = uiState.aspectRatio == "9:16"
                FilterChip(
                    selected = is916,
                    onClick = { onAspectRatioChanged("9:16") },
                    label = { Text("9:16 Portrait", fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                    leadingIcon = { Icon(Icons.Default.CropPortrait, null, modifier = Modifier.size(16.dp)) },
                    shape = RoundedCornerShape(50),
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color.Transparent,
                        labelColor = MinimalTextSecondary,
                        selectedContainerColor = MinimalPrimaryContainer,
                        selectedLabelColor = MinimalOnPrimaryContainer,
                        selectedLeadingIconColor = MinimalOnPrimaryContainer
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = is916,
                        borderColor = MinimalBorder,
                        selectedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(26.dp))

            // Primary Generate Button matching Clean Minimalism (rounded-full, #6750A4, 56dp)
            Button(
                onClick = onGenerateClicked,
                enabled = !uiState.isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("generate_button"),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalPrimary,
                    contentColor = Color.White,
                    disabledContainerColor = MinimalPrimary.copy(alpha = 0.5f),
                    disabledContentColor = Color.White.copy(alpha = 0.7f)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp, pressedElevation = 1.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (uiState.isGenerating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.btn_generating),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.btn_generate),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }

        // Live Generation Modal Dialog
        if (uiState.isGenerating) {
            Dialog(onDismissRequest = {}) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MinimalSurfaceElevated),
                    border = BorderStroke(1.dp, MinimalBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                progress = { uiState.progress },
                                color = MinimalPrimary,
                                trackColor = MinimalBorder,
                                modifier = Modifier.size(72.dp),
                                strokeWidth = 5.dp
                            )
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MinimalPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "Creating AI Video Clip",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MinimalTextPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = uiState.statusMessage.ifBlank { "Processing motion synthesis..." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MinimalTextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        LinearProgressIndicator(
                            progress = { uiState.progress },
                            color = MinimalPrimary,
                            trackColor = MinimalBorder,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "${(uiState.progress * 100).toInt()}% completed",
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalPrimary
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedButton(
                            onClick = onCancelGeneration,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, MinimalBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalTextSecondary)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }
    }
}
