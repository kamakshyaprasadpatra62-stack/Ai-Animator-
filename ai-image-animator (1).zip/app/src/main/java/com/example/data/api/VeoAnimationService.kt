package com.example.data.api

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class VeoAnimationService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "VeoAnimationService"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        const val MODEL_VEO_FAST = "veo-3.1-fast-generate-preview"
        const val MODEL_VEO_HD = "veo-3.1-generate-preview"
        const val MODEL_VEO_2 = "veo-2.0-generate-001"
    }

    suspend fun generateVideoWithVeo(
        apiKey: String,
        bitmap: Bitmap,
        prompt: String,
        aspectRatio: String = "16:9",
        model: String = MODEL_VEO_FAST,
        onProgress: (String, Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            throw IllegalArgumentException("API Key is missing. Please set your Gemini API key.")
        }

        onProgress("Optimizing image for Veo AI animation...", 0.10f)
        val base64Image = bitmapToBase64(bitmap)

        onProgress("Submitting generation request to $model...", 0.25f)
        val requestJson = JSONObject().apply {
            put("prompt", prompt)
            put("image", JSONObject().apply {
                put("imageBytes", base64Image)
                put("mimeType", "image/jpeg")
            })
            put("config", JSONObject().apply {
                put("numberOfVideos", 1)
                put("aspectRatio", if (aspectRatio == "9:16") "9:16" else "16:9")
                put("resolution", "720p")
            })
        }

        val url = "$BASE_URL/models/$model:generateVideos?key=$apiKey"
        val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
        val httpRequest = Request.Builder()
            .url(url)
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
            .build()

        val response = client.newCall(httpRequest).execute()
        val responseBodyString = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            Log.e(TAG, "Veo API Error (${response.code}): $responseBodyString")
            throw Exception("Veo API Error (${response.code}): ${parseErrorMessage(responseBodyString)}")
        }

        val responseJson = JSONObject(responseBodyString)
        val operationName = responseJson.optString("name")
        if (operationName.isNullOrEmpty()) {
            throw Exception("Failed to retrieve operation name from Veo API.")
        }

        Log.d(TAG, "Veo Operation created: $operationName")
        onProgress("AI motion synthesis in progress...", 0.40f)

        // Poll operation until completion
        val maxAttempts = 60
        var attempt = 0
        var isDone = false
        var resultVideoUri: String? = null
        var resultBase64Video: String? = null

        while (attempt < maxAttempts && !isDone) {
            delay(4000)
            attempt++
            val progressVal = 0.40f + (attempt.toFloat() / maxAttempts.toFloat()) * 0.45f
            onProgress("Synthesizing animation frames (Step $attempt)...", progressVal)

            val pollUrl = if (operationName.startsWith("http")) {
                "$operationName?key=$apiKey"
            } else {
                "$BASE_URL/$operationName?key=$apiKey"
            }

            val pollRequest = Request.Builder().url(pollUrl).get().build()
            val pollResponse = client.newCall(pollRequest).execute()
            val pollBodyString = pollResponse.body?.string() ?: ""

            if (!pollResponse.isSuccessful) {
                Log.w(TAG, "Poll attempt $attempt error: $pollBodyString")
                continue
            }

            val pollJson = JSONObject(pollBodyString)
            isDone = pollJson.optBoolean("done", false)

            if (isDone) {
                if (pollJson.has("error")) {
                    val errorObj = pollJson.getJSONObject("error")
                    val errMsg = errorObj.optString("message", "Unknown error during Veo generation")
                    throw Exception("Veo generation failed: $errMsg")
                }

                val respObj = pollJson.optJSONObject("response")
                if (respObj != null) {
                    val genVideos = respObj.optJSONArray("generatedVideos")
                    if (genVideos != null && genVideos.length() > 0) {
                        val videoObj = genVideos.getJSONObject(0).optJSONObject("video")
                        if (videoObj != null) {
                            resultVideoUri = if (videoObj.has("uri")) videoObj.getString("uri") else null
                            resultBase64Video = if (videoObj.has("bytesBase64Encoded")) videoObj.getString("bytesBase64Encoded") else null
                        }
                    }
                }
            }
        }

        if (!isDone) {
            throw Exception("Video generation timed out. The operation is still running on Google Cloud.")
        }

        onProgress("Downloading final video clip...", 0.90f)
        val videosDir = File(context.filesDir, "animated_videos").apply { mkdirs() }
        val outputFile = File(videosDir, "veo_${System.currentTimeMillis()}.mp4")

        if (!resultBase64Video.isNullOrEmpty()) {
            val videoBytes = Base64.decode(resultBase64Video, Base64.DEFAULT)
            outputFile.writeBytes(videoBytes)
        } else if (!resultVideoUri.isNullOrEmpty()) {
            val downloadUrl = if (resultVideoUri!!.contains("?")) {
                "$resultVideoUri&key=$apiKey"
            } else {
                "$resultVideoUri?key=$apiKey"
            }

            val downloadRequest = Request.Builder()
                .url(downloadUrl)
                .addHeader("x-goog-api-key", apiKey)
                .get()
                .build()

            val dlResponse = client.newCall(downloadRequest).execute()
            if (!dlResponse.isSuccessful) {
                throw Exception("Failed to download video file (${dlResponse.code})")
            }
            dlResponse.body?.byteStream()?.use { input ->
                FileOutputStream(outputFile).use { output ->
                    input.copyTo(output)
                }
            }
        } else {
            throw Exception("Veo finished but returned no video stream or URI.")
        }

        onProgress("Animation successfully created!", 1.0f)
        outputFile
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        // Resize bitmap to max dimension 1280 to maintain aspect ratio and fast upload
        val maxDim = 1280
        val width = bitmap.width
        val height = bitmap.height
        val scaledBitmap = if (width > maxDim || height > maxDim) {
            val ratio = width.toFloat() / height.toFloat()
            val newWidth: Int
            val newHeight: Int
            if (width > height) {
                newWidth = maxDim
                newHeight = (maxDim / ratio).toInt()
            } else {
                newHeight = maxDim
                newWidth = (maxDim * ratio).toInt()
            }
            Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
        } else {
            bitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    private fun parseErrorMessage(jsonString: String): String {
        return try {
            val obj = JSONObject(jsonString)
            if (obj.has("error")) {
                obj.getJSONObject("error").optString("message", jsonString)
            } else {
                jsonString
            }
        } catch (e: Exception) {
            jsonString
        }
    }
}
