package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "animations")
data class AnimationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val prompt: String,
    val imagePath: String,
    val videoPath: String,
    val aspectRatio: String = "16:9",
    val motionStyle: String = "Cinematic Flow",
    val modelName: String = "Veo 3.1 Fast",
    val timestamp: Long = System.currentTimeMillis()
)
