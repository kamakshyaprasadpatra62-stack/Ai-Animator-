package com.example.data.repository

import com.example.data.local.AnimationDao
import com.example.data.model.AnimationItem
import kotlinx.coroutines.flow.Flow

class AnimationRepository(private val animationDao: AnimationDao) {
    val allAnimations: Flow<List<AnimationItem>> = animationDao.getAllAnimations()

    suspend fun insertAnimation(item: AnimationItem): Long {
        return animationDao.insertAnimation(item)
    }

    suspend fun deleteAnimationById(id: Long) {
        animationDao.deleteAnimationById(id)
    }

    suspend fun clearAll() {
        animationDao.clearAll()
    }
}
