package com.example.data.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sin

class LocalMotionVideoSynthesizer(private val context: Context) {

    companion object {
        private const val TAG = "LocalMotionVideo"
    }

    suspend fun synthesizeMotionVideo(
        bitmap: Bitmap,
        prompt: String,
        aspectRatio: String = "16:9",
        durationSeconds: Int = 4,
        onProgress: (String, Float) -> Unit
    ): File = withContext(Dispatchers.Default) {
        val width = if (aspectRatio == "9:16") 720 else 1280
        val height = if (aspectRatio == "9:16") 1280 else 720
        val fps = 24
        val totalFrames = durationSeconds * fps

        val outputDir = File(context.filesDir, "animated_videos").apply { mkdirs() }
        val outputFile = File(outputDir, "motion_${System.currentTimeMillis()}.mp4")

        onProgress("Initializing cinematic motion pipeline...", 0.1f)

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null

        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var trackIndex = -1
            var muxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val effectPaint = Paint(Paint.ANTI_ALIAS_FLAG)

            val isRain = prompt.contains("rain", ignoreCase = true) || prompt.contains("storm", ignoreCase = true)
            val isWater = prompt.contains("water", ignoreCase = true) || prompt.contains("cascade", ignoreCase = true) || prompt.contains("river", ignoreCase = true)
            val isNeon = prompt.contains("neon", ignoreCase = true) || prompt.contains("cyber", ignoreCase = true) || prompt.contains("glow", ignoreCase = true)
            val isZoomIn = !prompt.contains("zoom out", ignoreCase = true)

            val particles = List(40) {
                Particle(
                    x = Math.random().toFloat() * width,
                    y = Math.random().toFloat() * height,
                    speed = 2f + Math.random().toFloat() * 6f,
                    size = 2f + Math.random().toFloat() * 4f,
                    alpha = 100 + (Math.random() * 155).toInt()
                )
            }

            for (i in 0 until totalFrames) {
                val progressFrac = i.toFloat() / totalFrames.toFloat()
                onProgress("Synthesizing motion frames: ${i + 1}/$totalFrames", 0.1f + progressFrac * 0.75f)

                // Render frame onto surface canvas
                val canvas: Canvas = try {
                    inputSurface.lockHardwareCanvas()
                } catch (e: Exception) {
                    inputSurface.lockCanvas(null)
                }

                try {
                    // Compute cinematic camera motion
                    val scale = if (isZoomIn) {
                        1.0f + 0.18f * progressFrac
                    } else {
                        1.18f - 0.18f * progressFrac
                    }

                    val panX = sin(progressFrac * Math.PI.toFloat()) * (width * 0.04f)
                    val panY = sin(progressFrac * Math.PI.toFloat() * 0.5f) * (height * 0.03f)

                    canvas.save()
                    canvas.translate(width / 2f + panX, height / 2f + panY)
                    canvas.scale(scale, scale)
                    canvas.translate(-width / 2f, -height / 2f)

                    // Draw the base static image scaled to fill
                    val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
                    val dstRect = RectF(0f, 0f, width.toFloat(), height.toFloat())
                    canvas.drawBitmap(bitmap, srcRect, dstRect, paint)

                    // Atmospheric motion overlay
                    if (isNeon) {
                        val pulse = (sin(progressFrac * 12.0) * 0.5 + 0.5).toFloat()
                        effectPaint.shader = LinearGradient(
                            0f, 0f, width.toFloat(), height.toFloat(),
                            Color.argb((35 * pulse).toInt(), 168, 85, 247),
                            Color.argb((45 * (1f - pulse)).toInt(), 0, 229, 255),
                            Shader.TileMode.CLAMP
                        )
                        canvas.drawRect(dstRect, effectPaint)
                        effectPaint.shader = null
                    } else if (isWater) {
                        val wave = (sin(progressFrac * 10.0 + 1.0) * 0.5 + 0.5).toFloat()
                        effectPaint.color = Color.argb((25 + 20 * wave).toInt(), 0, 200, 255)
                        canvas.drawRect(0f, height * 0.65f, width.toFloat(), height.toFloat(), effectPaint)
                    }

                    // Motion Particles / Rain / Embers
                    particles.forEach { p ->
                        p.y += p.speed
                        if (p.y > height) {
                            p.y = 0f
                            p.x = Math.random().toFloat() * width
                        }
                        effectPaint.color = if (isRain) {
                            Color.argb(p.alpha, 200, 230, 255)
                        } else if (isNeon) {
                            Color.argb(p.alpha, 255, 100, 220)
                        } else {
                            Color.argb(p.alpha, 255, 255, 200)
                        }
                        if (isRain) {
                            canvas.drawLine(p.x, p.y, p.x - 2f, p.y + p.size * 3.5f, effectPaint)
                        } else {
                            canvas.drawCircle(p.x, p.y, p.size, effectPaint)
                        }
                    }

                    // Vignette & Cinematic contrast grading
                    val vignette = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(Color.argb(50, 0, 0, 0), Color.TRANSPARENT, Color.argb(80, 0, 0, 0)),
                        floatArrayOf(0f, 0.4f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    effectPaint.shader = vignette
                    canvas.drawRect(dstRect, effectPaint)
                    effectPaint.shader = null

                    canvas.restore()
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                drainEncoder(encoder, muxer, bufferInfo, false) { idx, started ->
                    trackIndex = idx
                    muxerStarted = started
                }
            }

            // Signal end of stream
            encoder.signalEndOfInputStream()
            drainEncoder(encoder, muxer, bufferInfo, true) { idx, started ->
                trackIndex = idx
                muxerStarted = started
            }

            onProgress("Finalizing MP4 video clip...", 0.95f)

        } catch (e: Exception) {
            Log.e(TAG, "Error synthesizing motion video: ${e.message}", e)
            throw e
        } finally {
            try {
                encoder?.stop()
                encoder?.release()
                inputSurface?.release()
                if (muxer != null) {
                    try {
                        muxer.stop()
                        muxer.release()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error closing muxer", e)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Cleanup exception", e)
            }
        }

        onProgress("Animation ready!", 1.0f)
        outputFile
    }

    private fun drainEncoder(
        encoder: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onMuxerState: (Int, Boolean) -> Unit
    ) {
        var trackIndex = -1
        var muxerStarted = false

        while (true) {
            val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break else continue
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val newFormat = encoder.outputFormat
                trackIndex = muxer.addTrack(newFormat)
                muxer.start()
                muxerStarted = true
                onMuxerState(trackIndex, muxerStarted)
            } else if (outputBufferIndex >= 0) {
                val encodedData = encoder.getOutputBuffer(outputBufferIndex)
                if (encodedData != null) {
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        bufferInfo.size = 0
                    }

                    if (bufferInfo.size != 0) {
                        muxer.writeSampleData(if (trackIndex >= 0) trackIndex else 0, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        break
                    }
                }
            }
        }
    }

    private data class Particle(
        var x: Float,
        var y: Float,
        val speed: Float,
        val size: Float,
        val alpha: Int
    )
}
