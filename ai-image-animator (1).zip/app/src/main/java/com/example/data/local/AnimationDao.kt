package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.AnimationItem
import kotlinx.coroutines.flow.Flow

@Dao
interface AnimationDao {
    @Query("SELECT * FROM animations ORDER BY timestamp DESC")
    fun getAllAnimations(): Flow<List<AnimationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimation(item: AnimationItem): Long

    @Query("DELETE FROM animations WHERE id = :id")
    suspend fun deleteAnimationById(id: Long)

    @Query("DELETE FROM animations")
    suspend fun clearAll()
}
