package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AnimationViewModel
import com.example.ui.components.ApiKeyDialog
import com.example.ui.screens.CreateAnimationScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.VideoResultScreen
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalPrimary
import com.example.ui.theme.MinimalSecondaryContainer
import com.example.ui.theme.MinimalSurfaceElevated
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
  private val viewModel: AnimationViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme(darkTheme = false) {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val historyList by viewModel.savedAnimations.collectAsStateWithLifecycle()

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = MaterialTheme.colorScheme.background,
          bottomBar = {
            NavigationBar(
              containerColor = MinimalSurfaceElevated,
              contentColor = MinimalPrimary,
              modifier = Modifier.drawBehind {
                drawLine(
                  color = MinimalBorder,
                  start = Offset(0f, 0f),
                  end = Offset(size.width, 0f),
                  strokeWidth = 1.dp.toPx()
                )
              }
            ) {
              NavigationBarItem(
                selected = uiState.selectedTab == 0,
                onClick = { viewModel.onTabSelected(0) },
                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                label = { Text(stringResource(R.string.tab_create)) },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = MinimalPrimary,
                  selectedTextColor = MinimalPrimary,
                  indicatorColor = MinimalSecondaryContainer,
                  unselectedIconColor = MinimalTextSecondary,
                  unselectedTextColor = MinimalTextSecondary
                ),
                modifier = Modifier.testTag("nav_create_tab")
              )

              NavigationBarItem(
                selected = uiState.selectedTab == 1,
                onClick = { viewModel.onTabSelected(1) },
                icon = { Icon(Icons.Default.Movie, contentDescription = null) },
                label = { Text(stringResource(R.string.tab_preview)) },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = MinimalPrimary,
                  selectedTextColor = MinimalPrimary,
                  indicatorColor = MinimalSecondaryContainer,
                  unselectedIconColor = MinimalTextSecondary,
                  unselectedTextColor = MinimalTextSecondary
                ),
                modifier = Modifier.testTag("nav_preview_tab")
              )

              NavigationBarItem(
                selected = uiState.selectedTab == 2,
                onClick = { viewModel.onTabSelected(2) },
                icon = { Icon(Icons.Default.History, contentDescription = null) },
                label = { Text(stringResource(R.string.tab_history)) },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = MinimalPrimary,
                  selectedTextColor = MinimalPrimary,
                  indicatorColor = MinimalSecondaryContainer,
                  unselectedIconColor = MinimalTextSecondary,
                  unselectedTextColor = MinimalTextSecondary
                ),
                modifier = Modifier.testTag("nav_history_tab")
              )
            }
          }
        ) { innerPadding ->
          when (uiState.selectedTab) {
            0 -> CreateAnimationScreen(
              uiState = uiState,
              onImagePicked = { uri -> viewModel.onImageSelected(uri) },
              onSampleSelected = { resId, prompt -> viewModel.onSampleSelected(resId, prompt) },
              onPromptChanged = { prompt -> viewModel.onPromptChange(prompt) },
              onAspectRatioChanged = { ratio -> viewModel.onAspectRatioChange(ratio) },
              onMotionStyleSelected = { style, prompt -> viewModel.onMotionStyleChange(style, prompt) },
              onGenerateClicked = { viewModel.generateAnimation() },
              onCancelGeneration = { viewModel.cancelGeneration() },
              onOpenSettings = { viewModel.toggleSettingsDialog(true) },
              onClearError = { viewModel.clearError() },
              modifier = Modifier.padding(innerPadding)
            )
            1 -> VideoResultScreen(
              animationItem = uiState.activeVideoItem,
              onGenerateNew = { viewModel.onTabSelected(0) },
              modifier = Modifier.padding(innerPadding)
            )
            2 -> HistoryScreen(
              items = historyList,
              onItemSelected = { item -> viewModel.setActiveVideo(item) },
              onDeleteItem = { item -> viewModel.deleteAnimation(item) },
              onStartCreate = { viewModel.onTabSelected(0) },
              modifier = Modifier.padding(innerPadding)
            )
          }

          if (uiState.showSettingsDialog) {
            ApiKeyDialog(
              currentKey = uiState.apiKey,
              currentEngineMode = uiState.engineMode,
              onSaveKey = { newKey -> viewModel.saveApiKey(newKey) },
              onEngineModeSelected = { mode -> viewModel.setEngineMode(mode) },
              onDismiss = { viewModel.toggleSettingsDialog(false) }
            )
          }
        }
      }
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme { Greeting("Android") }
}

